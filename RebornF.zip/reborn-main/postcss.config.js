module.exports = {
  plugins: {
    '@tailwindcss/postcss': {}, // This is the new v4 plugin
  },
}